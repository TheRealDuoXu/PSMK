import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ForkJoinPool;

public class FinancialCalculatorCore {
    public final static double BOLZANO_INIT = 1E-5;
    public final static double BOLZANO_STEP = 2E-5;

    public static double getNPV(ArrayDeque<Double> p_cashFlows, double discount) {
        Iterator<Double> cashFlows = p_cashFlows.iterator();
        double NPV = 0;
        int i = 0;

        while (cashFlows.hasNext()) {
            NPV += (cashFlows.next() / Math.pow((1 + discount), i));
            i++;
        }
        return NPV;
    }


    /**
     * ArrayDeque exigido porque es necesario conocer la longitud total de los objetos, Iterator no lo permite
     *
     * @param p_cashFlows
     * @return
     */
    public static double getIRRSchneider(ArrayDeque<Double> p_cashFlows) {
        ArrayDeque<Double> cashFlows = p_cashFlows.clone();
        double numerator, denominator;
        final int years = cashFlows.size();

        numerator = cashFlows.stream().reduce(Double::sum).orElseThrow(RuntimeException::new);

        // El denominador del método de Schneider no acumula la inversión inicial
        cashFlows.pop();
        denominator = cashFlows.stream().reduce((prev, next) -> prev + years * next).orElseThrow(RuntimeException::new);

        return numerator / denominator;
    }

    public static double getIRRBolzano(ArrayDeque<Double> cashFlows) {
        /*
        IRR is the value that zeroes the NPV
         */
        double IRR = BOLZANO_INIT, step = BOLZANO_STEP, previousNPV, actualNPV;
        boolean intersectsX = false;

        step *= bolzanoDirection(cashFlows, IRR);

        previousNPV = getNPV(cashFlows, IRR);
        while (!intersectsX) {
            IRR += step;
            actualNPV = getNPV(cashFlows, IRR);

            if (Math.signum(previousNPV) != Math.signum(actualNPV)) {
                intersectsX = true;
            } else {
                previousNPV = actualNPV;
            }
        }

        return IRR;
    }

    public static Double getIRRBolzano(ArrayDeque<Double> cashFlows, double startIRR, double maxIRR, double step) {
        double IRR = startIRR, previousNPV, actualNPV;
        boolean intersectsX = false;

        step *= bolzanoDirection(cashFlows, IRR);

        previousNPV = getNPV(cashFlows, IRR);
        while (!intersectsX && (IRR >= maxIRR)) {
            IRR += step;
            actualNPV = getNPV(cashFlows, IRR);

            if (Math.signum(previousNPV) != Math.signum(actualNPV)) {
                intersectsX = true;
            } else {
                previousNPV = actualNPV;
            }
        }

        if (intersectsX) {
            return IRR;
        } else {
            return null;
        }
    }

    /**
     * Calculates bolzano direction, that depends on the current IRR, set to BOLZANO_INIT.
     * If current IRR makes NPV positive, then we must increment the IRR, thus direction is set positive
     * If current IRR makes NPV negative, then we must decrement the IRR, thus direction is set negative
     *
     * @param cashFlows Used to calculate the NPV, the cashFlows of the investment
     * @param IRR       Used to calculate the NPV, the starting point of getIRRBolzano
     * @return the sign of the VAN
     */
    private static double bolzanoDirection(ArrayDeque<Double> cashFlows, double IRR) {

        return Math.signum(getNPV(cashFlows, IRR));
    }

    /**
     * Precision takes time, you will need A LOT OF TIME and RAM to run this, and it is concurrent todo
     */
    public static double getPreciseIRRBolzano(ArrayDeque<Double> cashFlows) {
        ForkJoinPool forkJoinPool = ForkJoinPool.commonPool();
        Double IRR = forkJoinPool.invoke(new RecursiveBolzanoTask(cashFlows, RecursiveBolzanoTask.PRECISION_BOLZANO_INIT, RecursiveBolzanoTask.PRECISION_BOLZANO_MAX));
        ForkJoinPool.commonPool().shutdownNow();

        return IRRNullSafety(IRR);
    }

    private static double IRRNullSafety(Double IRR) {
        if (IRR == null) {
            throw new NullPointerException("No se ha encontrado el TIR, puede ser negativo o mayor que 2");
        } else {
            return IRR;
        }
    }
}
