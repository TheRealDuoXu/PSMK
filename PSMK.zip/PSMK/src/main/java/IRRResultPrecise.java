import java.util.ArrayDeque;
import java.util.LinkedList;

public class IRRResultPrecise extends IRRResult{
    public IRRResultPrecise(ArrayDeque<String> rawData) {
        super(rawData);
    }

    @Override
    public String getResultType() {
        return "IRR High Precision";
    }
}
